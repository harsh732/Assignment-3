﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SoftwareSales_Assignment3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SoftwareSales softwaresales;
        public MainWindow()
        {
            InitializeComponent();
            
            //instance of ViewModel object
             softwaresales = new SoftwareSales();
            //assign Vietmodel object to the View
            DataContext = softwaresales;
        }

        private void btn_Calculate_Click(object sender, RoutedEventArgs e)
        {

            lbl_Discount.Visibility = Visibility.Visible;
            lbl_Total.Visibility = Visibility.Visible;
            tbl_Discount.Visibility = Visibility.Visible;
            tbl_Total.Visibility = Visibility.Visible;
            softwaresales.CalculateSales(txt_Package.Text);
        }
    }
}
