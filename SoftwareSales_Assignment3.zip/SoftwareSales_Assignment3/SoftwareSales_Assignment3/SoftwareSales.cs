﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareSales_Assignment3
{
    class SoftwareSales : INotifyPropertyChanged
    {

        decimal _discount;
        decimal _totalValue;
        string _discount_Value;
        const decimal discount_20 = 0.2m;
        const decimal discount_30 = 0.3m;
        const decimal discount_40 = 0.4m;
        const decimal discount_50 = 0.5m;
        const decimal packageValue = 99;

        //public property
        public decimal discount
        {
            //return private variable when asked
            get { return _discount; }
            //set the private variable, and let anyone listening know it has changed
            set { _discount = value; NotifyPropertyChanged(); }
        }
        //public property
        public decimal totalValue
        {
            get { return _totalValue; }
            set { _totalValue = value; NotifyPropertyChanged(); }
        }

        // public property
        public string discount_Value
        {
            get { return _discount_Value; }
            set { _discount_Value = value; NotifyPropertyChanged(); }
        }

        //public method to calculate data
        public void CalculateSales(String textValue)
        {
            decimal value;

            decimal packageDetail;

            packageDetail = System.Convert.ToDecimal(textValue);

            value = packageValue * packageDetail;

            if (packageDetail < 10) {

                discount = 0;
                discount_Value = "0% Discount";
            }
            else if (packageDetail >= 10 && packageDetail <= 19)
            {
                discount = value * discount_20;
                discount_Value = "20% Discount";
            }
            else if (packageDetail >= 20 && packageDetail <= 49)
            {
                discount = value * discount_30;
                discount_Value = "30% Discount";
            }
            else if (packageDetail >= 50 && packageDetail <= 99)
            {
                discount = value * discount_40;
                discount_Value = "40% Discount";
            }
            else if (packageDetail >= 100)
            {
                discount = value * discount_50;
                discount_Value = "50% Discount";

            }
            totalValue = value - discount;
        }

        #region PropertyChangedImplementation
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

    }
}
